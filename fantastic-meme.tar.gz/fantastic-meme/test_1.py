class test:
    # def __init__(self, s):
    #    self.s = s

    def amazing(self, a):
        v = len(str(abs(a)))
        if a > 0:
            return 'Polojitelnoe chislo {} cifer'.format(v)
        elif a < 0:
            return 'Otricatelnoe chislo {} cifer'.format(v)
        return 'Zahem 0 napisal, odna cifra'


# def qwe(self):
#   return self.a, self.s

# def asd(self, f):
#   self.a += f


if __name__ == '__main__':
    z = int(input("Введите chislo: "))
    q = test()
    print(q.amazing(z))

    # q.asd(6)

    # print(q.qwe())
    # print(q.a)
    # print(q.s)
